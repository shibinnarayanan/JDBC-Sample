package com.svv;

import java.sql.*;

class DeletePrepared {
	public static void main(String args[]) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:Admin", "system",
					"admin@123");

			PreparedStatement stmt = con.prepareStatement("delete from Employee where id=?");
			stmt.setInt(1, 4);

			int i = stmt.executeUpdate();
			System.out.println(i + " records deleted");

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}