package com.svv;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo1 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		// Registering the driver class:
		Class.forName("oracle.jdbc.driver.OracleDriver");

		// Creating connection:
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:Admin", "system", "admin@123");
		// Creating the statement:
		Statement stmt = con.createStatement();
		// Executing the queries:
		int rsp = stmt.executeUpdate("insert into Employee (name,job) values ('shibin','engineer')");

		System.out.println(rsp);

		ResultSet rs = stmt.executeQuery("select * from Employee");
		while (rs.next()) {
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3));
		}
		// Closing connection:
		con.close();
	}

}

