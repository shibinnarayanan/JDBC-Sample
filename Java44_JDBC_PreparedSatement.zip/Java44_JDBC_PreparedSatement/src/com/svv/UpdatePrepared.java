package com.svv;

import java.sql.*;

class UpdatePrepared {
	public static void main(String args[]) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:Admin", "system",
					"admin@123");

			PreparedStatement stmt = con.prepareStatement("update Employee set name=? where id=?");
			stmt.setString(1, "Shibin Vettem Veettil");// 1 specifies the first parameter in the query i.e. name
			stmt.setInt(2, 26);

			int i = stmt.executeUpdate();
			System.out.println(i + " records updated");

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}